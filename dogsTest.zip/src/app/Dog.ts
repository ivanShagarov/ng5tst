export interface Dog {
  name: string;
  age: number;
  race: string;
}
